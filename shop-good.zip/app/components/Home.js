// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


//$scope.view.wdg["3DLabel-1"]["visible"]=true

//$scope.view.wdg["3DLabel-1"]["text"]="food is good"

// function   example  ...

//$scope.myfunction =function() {
  
//$scope.view.wdg["3DLabel-1"]["visible"]=true

//$scope.view.wdg["3DLabel-1"]["text"]="food is good"
//}


$scope.getDataFromTarget = function() {
   //$scope.view.wdg["model-1"]["visible"] = true
  //$scope.view.wdg["3DLabel-1"]["text"]="food is good";
}